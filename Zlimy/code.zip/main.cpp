#include "Engine/Engine.h"

using namespace IExtreme::Engine;

int main()
{
	Ugr::Engine g;
	g.run();

	/*sf::RenderWindow window(sf::VideoMode::getDesktopMode(), "");
	sf::Event event{};
	sf::RectangleShape shape(sf::Vector2f(100, 100));
	shape.setPosition(window.getSize().x * 0.5, 0);
	shape.setFillColor(sf::Color::Red);

	sf::RectangleShape ground(sf::Vector2f(900, 100));
	ground.setPosition(1920 * 0.5-900*0.5, 800);
	ground.setFillColor(sf::Color::Green);

	sf::Clock clock;
	float dt = 0.0f;
	sf::Vector2f vel(0, 0);
	const float jumpvelocity = -1'000;
	while (window.isOpen())
	{
		dt = clock.restart().asSeconds();
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Escape)
				window.close();
		}

		vel.y += 1000 * dt;
		
		bool collided = ground.getGlobalBounds().intersects(shape.getGlobalBounds());
		if (collided)
			vel.y = 0;

		if (collided && sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
			vel.y = jumpvelocity;
		shape.move(vel * dt);

		window.clear();
		window.draw(shape);
		window.draw(ground);
		window.display();
	}
	return EXIT_SUCCESS;*/
}