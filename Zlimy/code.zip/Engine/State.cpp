#include "State.h"
namespace IExtreme::Engine::Ugr
{
	bool State::getQuit() const
	{
		return quit;
	}
}