#include "logger.h"

namespace IExtreme::Engine::Ugr
{
	BYTE Logger::Color::defColor = 0x07;
	HANDLE Logger::Color::handle = nullptr;
}